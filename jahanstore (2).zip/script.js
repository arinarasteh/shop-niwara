
let cart = [];

function showSection(id) {
  document.querySelectorAll('section').forEach(s => s.style.display = 'none');
  document.getElementById(id).style.display = 'block';
}

function addToCart(name, price) {
  cart.push({ name, price });
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCart();
}

function updateCart() {
  const cartItems = document.getElementById('cartItems');
  const total = document.getElementById('total');
  cartItems.innerHTML = '';
  let sum = 0;
  cart.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.name} - ${item.price.toLocaleString()} تومان`;
    cartItems.appendChild(li);
    sum += item.price;
  });
  total.textContent = `مجموع: ${sum.toLocaleString()} تومان`;
}

function submitOrder(e) {
  e.preventDefault();
  const order = {
    name: document.getElementById('name').value,
    phone: document.getElementById('phone').value,
    address: document.getElementById('address').value,
    cart: cart
  };
  localStorage.setItem('orders', JSON.stringify(order));
  alert('سفارش ثبت شد!');
}
window.onload = () => {
  const savedCart = localStorage.getItem('cart');
  if (savedCart) {
    cart = JSON.parse(savedCart);
    updateCart();
  }
};
